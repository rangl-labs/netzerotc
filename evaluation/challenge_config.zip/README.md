# Challenge reference



## Getting started



Create the `evaluation_config.zip` file, ready of upload as a challenge to EvalAI.

```
./run.sh
```

